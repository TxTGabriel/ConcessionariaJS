const compradorModel = require('../models/compradorModel');

class CompradorController{

    async listar(req, res){
        //select * from aluno;
        const resultado = await compradorModel.find({});
        res.json(resultado);    
    }

    async buscarPorCodigo(req, res){
        const codigo  = req.params.codigo;
        //select * from aluno where codigo = 2;
        const resultado = await compradorModel.findOne({'codigo': codigo});
        res.json(resultado);
    }

    async salvar(req, res){
        const comprador = req.body;

        //Gerador de novo código
        const objeto = await compradorModel.findOne({}).sort({'codigo': -1});
        comprador.codigo = objeto == null ? 1 : objeto.codigo + 1;

        //insert into aluno (xxx) values (xxxx);
        const resultado = await compradorModel.create(comprador);
        res.json(resultado);        
    }

    async atualizar(req, res){
        const codigo = req.params.codigo;
        const comprador = req.body;
        //update aluno set xxxx values xxxx
        await compradorModel.findOneAndUpdate({'codigo': codigo}, comprador);
        res.send("Comprador atualizado!");
    }

    async excluir(req, res){
        const comprador = req.params.codigo;
        await alunoComprador.findOneAndDelete({'codigo': comprador});
        res.send("Comprador excluído!");
    }
}

module.exports = new CompradorController();