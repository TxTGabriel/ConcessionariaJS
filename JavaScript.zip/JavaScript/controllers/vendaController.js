const vendaModel = require('../models/vendaModel');

class VendaController {

    async listar(req, res){  
        //select * from emprestimo;
        const resultado = await vendaModel.find({});
        res.json(resultado);    
    }

    async buscarPorCodigo(req, res){
        const codigo  = req.params.codigo;
        //select * from emprestimo where codigo = 2;
        const resultado = await vendaModel.findOne({'codigo': codigo});
        res.json(resultado);
    }

    async salvar(req, res){
        const venda = req.body;

        //Gerador de novo código
        //select * from emprestimo order by codigo desc;
        const objeto = await vendaModel.findOne({}).sort({'codigo': -1});
        venda.codigo = objeto == null ? 1 : objeto.codigo + 1;

        //insert into emprestimo (xxx) values (xxxx);
        const resultado = await vendaModel.create(venda);
        res.json(resultado);        
    }

    async atualizar(req, res){
        const codigo = req.params.codigo;
        const venda = req.body;
        //update emprestimo set xxxx values xxxx
        await vendaModel.findOneAndUpdate({'codigo': codigo}, venda);
        res.send("Venda atualizado!");
    }

    async excluir(req, res){
        const codigo = req.params.codigo;
        await vendaModel.findOneAndDelete({'codigo': codigo});
        res.send("Venda excluído!");
    }
}

module.exports = new VendaController();