const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const VeiculoSchema = new Schema({

    codigo: Number,
    modelo: {
        type: String,
        required: [true, "nome é obrigatório!"]
    },
    codigoVenda: {
        type: String,
        required: [true, "codigo é obrigatório!"]
    },
    cor: 
    {
        type: String,
        required: [true, "Sinopse é uma informação obrigatória!"]
    },
    portas: 
    {
        type: String,
        required: [false, "Autor é obrigatório!"]
    }
});

module.exports = mongoose.model('veiculo', VeiculoSchema);
