const mongoose = require('mongoose');

const Schema = mongoose.Schema;

var date = new Date()

const VendaSchema = new Schema
(
    {
        codigo: Number,
        informacoesComprador: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'comprador'
        },
        veiculoComprado: {
            type: mongoose.Schema.Types.ObjectId,
            ref:'veiculo'
        },
        comprovanteEmissao: {
            type: Date,
            default: Date.now()
        }
    }
);

module.exports = mongoose.model('venda', VendaSchema);