require("./db/mongo");
const express = require("express");
const srv = express();
srv.use(express.json());

//Roteamento das rotas de conteúdo
const compradorRouter = require('./routes/compradorRouter');
srv.use('/comprador', compradorRouter);

const veiculoRouter = require('./routes/veiculoRouter');
srv.use('/veiculo', veiculoRouter);

const vendaRouter = require('./routes/vendaRouter');
srv.use('/venda', vendaRouter);

srv.listen(3000, function(){
    console.log('Concessionaria rodando em http://localhost:3000');
});