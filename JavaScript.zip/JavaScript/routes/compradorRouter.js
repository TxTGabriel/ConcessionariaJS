const compradorController = require('../controllers/compradorController');
const express = require('express');

const router = express.Router();

router.get('/', compradorController.listar);
router.get('/:codigo', compradorController.buscarPorCodigo);
router.post('/', compradorController.salvar);
router.put('/:codigo', compradorController.atualizar);
router.delete('/:codigo', compradorController.excluir);

module.exports = router;