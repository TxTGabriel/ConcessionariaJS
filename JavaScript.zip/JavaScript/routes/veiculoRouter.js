const veiculoController = require('../controllers/veiculoController');
const express = require('express');

const router = express.Router();

router.get('/', veiculoController.listar);
router.get('/:codigo', veiculoController.buscarPorCodigo);
router.post('/', veiculoController.salvar);
router.put('/:codigo', veiculoController.atualizar);
router.delete('/:codigo', veiculoController.excluir);

module.exports = router;